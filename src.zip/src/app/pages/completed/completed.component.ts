import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed',
  imports: [],
  templateUrl: './completed.component.html',
  styleUrl: './completed.component.css'
})
export class CompletedComponent implements OnInit{
  constructor(){console.log("Constructor works");}
  ngOnInit(): void {
    console.log('Method works.');
  }
}
